/* ==========================================================================
   PURE JAVASCRIPT - LUMEN PHOTOGRAPHY PORTFOLIO MANAGER
   File: script.js
   ========================================================================== */

const PHOTOS = [
  {
    id: 'p-01',
    title: 'Monolith & Scaffolding — Carrara Light',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCKuYwQ6-sQ5uY59d3rX32j1h4yH74n8vNqfP4B0J8sM6-bK5Q',
    camera: 'Leica M11',
    lens: 'Noctilux-M 50mm f/0.95',
    aperture: 'f/1.4',
    shutter: '1/1000s',
    iso: '64',
    dimensions: '9528 × 6328',
    shoot: 'fashion',
    score: 99
  },
  {
    id: 'p-02',
    title: 'Brutalist Flâneur — Charcoal Wool',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA9kKk9qO9K3wY9u1mN0jF2sK8m4B9zV3xY5n2bL',
    camera: 'Hasselblad X2D 100C',
    lens: 'XCD 55mm f/2.5 V',
    aperture: 'f/2.8',
    shutter: '1/800s',
    iso: '100',
    dimensions: '11656 × 8742',
    shoot: 'fashion',
    score: 97
  },
  {
    id: 'p-03',
    title: 'Profile in Chiaroscuro',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCk1SWk3-_YAJ6ejmeOFqrdQCBiutv-L02cVZ2JxCeJD19_u4usy9cEcUCMmNtN-R3LOTJxYQ9jsFf6No0eUyZFwrRxaWEmECt1DCzmkLUMUMCha8OCxos_JYtjR61SzSAKe4iS7Q2gmM7yGVAYu2zNnyjgcN7xZPvjXmh75QgbNyY0um4E2iFtwWDW_9jisIVsGA3neNHWI5ohXhCNxkhWQKQQIoQWXEgumcfRU57hnd76Elw8wqNeOg',
    camera: 'Sony A7R V',
    lens: 'FE 85mm f/1.4 GM II',
    aperture: 'f/1.4',
    shutter: '1/500s',
    iso: '100',
    dimensions: '9504 × 6336',
    shoot: 'fashion',
    score: 98
  },
  {
    id: 'p-04',
    title: 'Studio Chiaroscuro Portrait',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA3hRoNb_n8NbYmvYZIaqTwQUF5EiNaefsOc1wMpBvRvhqF2V6IWw7sIlcoCH7Q78qvFb-xVEC0a016_jTbOlwm0GqZTJ-wqDRZ8aJ8y6fxzcHcFEdr7xgZyaQ1_8xb3WnYUtYIEVi1gQ3erLxjiyW4dOWIbh-icJwT9ZKy4pl8nOml9mm1EW0SKMYI2w05aW7R7TgOMNDWO3RqyAbMyoCCVjQWwbzsLk3OmVHByN5q05zzH9ablha-gA',
    camera: 'Sony A7R V',
    lens: 'FE 50mm f/1.2 GM',
    aperture: 'f/2.0',
    shutter: '1/640s',
    iso: '100',
    dimensions: '9504 × 6336',
    shoot: 'fashion',
    score: 94
  },
  {
    id: 'p-05',
    title: 'Studio Light Elena V. (Near Duplicate)',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCo4O7a24DOdbSXeCKa_JrwVkO1IdV_-wRBwgaG-Bf1Wu-VR_lrnFglmVNAL0m3U5RNAOEnKKFPLFvHI3tfxCSyhcQQHjbl3z_yul_UmlyOBleMl79M29igEfji01QqX6DZ9-IT4jqMgFDn1P0noCbJ1eQz3D1pxbzXCLrAIffCnA2Tl4daviwKY3ay0AoohrvwhInjKKx7prjLHCTWyotFWYbVkVnZisJoqravnELLp9xEkHbVtgMr_A',
    camera: 'Sony A7R V',
    lens: 'FE 50mm f/1.2 GM',
    aperture: 'f/2.0',
    shutter: '1/640s',
    iso: '100',
    dimensions: '9504 × 6336',
    shoot: 'fashion',
    score: 91
  },
  {
    id: 'p-06',
    title: 'Bridal Preparation Window Spill',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCHZ46p-g92wF6fR9f0xL_U7YyF02eC0qJb3g1M4oE9',
    camera: 'Sony A7R V',
    lens: 'FE 50mm f/1.2 GM',
    aperture: 'f/1.4',
    shutter: '1/500s',
    iso: '100',
    dimensions: '9504 × 6336',
    shoot: 'wedding',
    score: 98
  },
  {
    id: 'p-07',
    title: 'Palace Colonnade Golden Hour',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB2sWE9J3Agp3k-cQYP9Fmnbnslv76E-9rqPmgNho-Soxszm35WkID-3OIaB-ZpoL_duaqzO0SZaFGX4KWJUKKq5uJHcsERQeKCqJ3LYMaLv9x5FwpbPlgJFjkmodi_ORcOz5K8Zjx5lmq6et6sycFPJU52JL5iqnR9m5UVzZKmd_KGZBtzzPi7n3ruRFQ7qiv2mPLp0UazpEelHstekv8pKOTpFZA7l0NCJhjiLd0s5zPouEbFYMuXxg',
    camera: 'Sony A7R V',
    lens: 'FE 85mm f/1.4 GM II',
    aperture: 'f/1.4',
    shutter: '1/1000s',
    iso: '100',
    dimensions: '9504 × 6336',
    shoot: 'wedding',
    score: 99
  },
  {
    id: 'p-08',
    title: 'Raw Tweed Weave Macro',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA2OHs0yi5R50YIrUIa01lCh9Pla6BT4w5E84wr3cwC0t-ReXPkRvX0m1OLw-GLLs-oNCj4glkG-RmFk7sT17ZKtjMukHzfg20XcTRmEvxRG_iw5JjCZcEFY4kNOz3Wjbw2mbNNHkHPx2dJ_mGpa9M1j4MOgvowrsQSSRUUG8FGBOJFGCLKOHU0icMg9w46OGJN0ZQBZSOKloygsRkUY_pM-o176MZP0KbaRmx41fvwg9MAgf9eTK7bEg',
    camera: 'Canon EOS R5',
    lens: 'RF 100mm f/2.8L Macro',
    aperture: 'f/5.6',
    shutter: '1/250s',
    iso: '100',
    dimensions: '8192 × 5464',
    shoot: 'fashion',
    score: 92
  }
];

let currentRole = 'OWNER';

// SCREEN SWITCHING
function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = document.getElementById('screen-' + screenId);
  if (target) target.classList.add('active');

  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  const activeBtn = Array.from(document.querySelectorAll('.nav-btn')).find(b => b.getAttribute('onclick')?.includes(screenId));
  if (activeBtn) activeBtn.classList.add('active');

  if (screenId === 'library') renderLibrary();
  if (screenId === 'dashboard') renderDashboard();
  if (screenId === 'suggestions') renderSuggestions();
  if (screenId === 'editor') renderEditor();
  if (screenId === 'preview') renderPreview();
  if (screenId === 'proofing') renderProofing();
}

// RENDER DASHBOARD
function renderDashboard() {
  const container = document.getElementById('dashboard-recent-grid');
  if (!container) return;
  container.innerHTML = PHOTOS.slice(0, 4).map(p => `
    <div class="photo-card" onclick="openPhotoDetail('${p.id}')">
      <img src="${p.url}" alt="${p.title}">
      <div class="photo-card-info">
        <div class="photo-card-title">${p.title}</div>
        <div class="photo-card-exif">${p.camera} · ${p.lens}</div>
      </div>
    </div>
  `).join('');
}

// RENDER LIBRARY
function renderLibrary() {
  const container = document.getElementById('main-photo-grid');
  if (!container) return;
  container.innerHTML = PHOTOS.map(p => `
    <div class="photo-card" onclick="openPhotoDetail('${p.id}')">
      <img src="${p.url}" alt="${p.title}">
      <div class="photo-card-info">
        <div class="photo-card-title">${p.title}</div>
        <div class="photo-card-exif">${p.camera} · ${p.aperture}</div>
        <div style="margin-top: 4px; display: flex; justify-content: space-between;">
          <span class="badge badge-accent">${p.shoot.toUpperCase()}</span>
          <span style="font-size: 11px; font-weight: 600; color: var(--green);">${p.score} Score</span>
        </div>
      </div>
    </div>
  `).join('');
}

// FILTER PHOTOS
function filterPhotos() {
  const query = document.getElementById('library-search').value.toLowerCase();
  const shoot = document.getElementById('library-shoot-filter').value;
  const filtered = PHOTOS.filter(p => {
    const matchesQuery = p.title.toLowerCase().includes(query) || p.camera.toLowerCase().includes(query);
    const matchesShoot = shoot === 'all' || p.shoot === shoot;
    return matchesQuery && matchesShoot;
  });

  const container = document.getElementById('main-photo-grid');
  if (!container) return;
  container.innerHTML = filtered.map(p => `
    <div class="photo-card" onclick="openPhotoDetail('${p.id}')">
      <img src="${p.url}" alt="${p.title}">
      <div class="photo-card-info">
        <div class="photo-card-title">${p.title}</div>
        <div class="photo-card-exif">${p.camera} · ${p.aperture}</div>
      </div>
    </div>
  `).join('');
}

// PHOTO DETAIL DRAWER
function openPhotoDetail(photoId) {
  const photo = PHOTOS.find(p => p.id === photoId);
  if (!photo) return;

  document.getElementById('drawer-title').innerText = photo.title;
  document.getElementById('drawer-content').innerHTML = `
    <img src="${photo.url}" style="width: 100%; height: 260px; object-fit: cover; border-radius: 8px; margin-bottom: 20px;" alt="${photo.title}">
    <div class="card" style="margin-bottom: 16px;">
      <h4 style="font-size: 13px; font-family: 'JetBrains Mono', monospace; margin-bottom: 10px; color: var(--text-light);">CAMERA &amp; OPTICS</h4>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px;">
        <div><strong>Camera:</strong> ${photo.camera}</div>
        <div><strong>Lens:</strong> ${photo.lens}</div>
        <div><strong>Aperture:</strong> ${photo.aperture}</div>
        <div><strong>Shutter:</strong> ${photo.shutter}</div>
        <div><strong>ISO:</strong> ${photo.iso}</div>
        <div><strong>Dimensions:</strong> ${photo.dimensions}</div>
      </div>
    </div>
    <div style="display: flex; gap: 8px;">
      <button class="btn btn-outline" style="flex: 1;" onclick="toast('Photo added to favorites')">★ Favorite</button>
      ${currentRole === 'OWNER' ? `<button class="btn btn-outline" style="color: #c00;" onclick="deletePhoto('${photo.id}')">Delete RAW</button>` : ''}
    </div>
  `;
  document.getElementById('photo-drawer').classList.add('open');
}

function closeDrawer() {
  document.getElementById('photo-drawer').classList.remove('open');
}

// AI SUGGESTIONS
function generateAiSuggestions() {
  toast('Analyzing 247 candidate photos against recruiter brief...');
  setTimeout(() => {
    showScreen('suggestions');
  }, 600);
}

function renderSuggestions() {
  const container = document.getElementById('suggestions-grid');
  if (!container) return;
  container.innerHTML = PHOTOS.map((p, idx) => `
    <div class="card" style="display: flex; flex-direction: column;">
      <img src="${p.url}" style="width: 100%; height: 180px; object-fit: cover; border-radius: 6px; margin-bottom: 10px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
        <span class="badge badge-accent">PLATE 0${idx + 1}</span>
        <span style="font-size: 11px; font-weight: 700; color: var(--green);">${p.score}% MATCH</span>
      </div>
      <strong style="font-size: 13px;">${p.title}</strong>
      <p style="font-size: 11px; color: var(--text-muted); margin-top: 4px; flex: 1;">
        ${idx === 0 ? 'Strong opening image anchor with brutalist geometry' : 'Adds visual variety and editorial silhouette pacing'}
      </p>
      <div style="display: flex; gap: 6px; margin-top: 12px;">
        <button class="btn btn-primary btn-sm" style="flex: 1;" onclick="toast('Plate accepted into sequence')">Accept</button>
        <button class="btn btn-outline btn-sm" onclick="toast('Alternative recommended')">Replace</button>
      </div>
    </div>
  `).join('');
}

function applySuggestionsToEditor() {
  toast('Transferred 15 recommended plates to Portfolio Sequence Editor');
  showScreen('editor');
}

// PORTFOLIO EDITOR
function renderEditor() {
  const container = document.getElementById('editor-plates-grid');
  if (!container) return;
  container.innerHTML = PHOTOS.map((p, idx) => `
    <div class="card">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
        <span class="badge badge-dark">PLATE 0${idx + 1}</span>
        ${idx === 0 ? '<span class="badge badge-accent">COVER HERO</span>' : ''}
      </div>
      <img src="${p.url}" style="width: 100%; height: 160px; object-fit: cover; border-radius: 6px; margin-bottom: 8px;">
      <div style="font-size: 12px; font-weight: 600;">${p.title}</div>
      <div style="display: flex; gap: 6px; margin-top: 10px;">
        <button class="btn btn-outline btn-sm" onclick="toast('Plate moved up in sequence')">↑</button>
        <button class="btn btn-outline btn-sm" onclick="toast('Plate moved down in sequence')">↓</button>
        <button class="btn btn-outline btn-sm" onclick="toast('Assigned as Cover Hero')">Set Cover</button>
      </div>
    </div>
  `).join('');
}

// FINAL PREVIEW
function renderPreview() {
  const container = document.getElementById('preview-plates-container');
  if (!container) return;
  container.innerHTML = `
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-top: 24px;">
      ${PHOTOS.slice(0, 6).map(p => `
        <div>
          <img src="${p.url}" style="width: 100%; height: 200px; object-fit: cover; border-radius: 6px;" alt="Plate">
          <div style="font-size: 11px; color: #ccc; margin-top: 6px;">${p.title}</div>
        </div>
      `).join('')}
    </div>
  `;
}

function publishPortfolio() {
  if (currentRole !== 'OWNER') {
    toast('Action Denied: Only Studio Owner can publish portfolios live.');
    return;
  }
  toast('🎉 Portfolio published to live URL: https://lumen.studio/p/aarav-patel');
  const btn = document.getElementById('publish-btn');
  if (btn) {
    btn.innerText = '✓ Published Live';
    btn.classList.remove('btn-accent');
    btn.classList.add('btn-outline');
  }
}

// CLIENT PROOFING
function renderProofing() {
  const container = document.getElementById('proofing-grid');
  if (!container) return;
  container.innerHTML = PHOTOS.map((p, idx) => `
    <div class="card">
      <img src="${p.url}" style="width: 100%; height: 200px; object-fit: cover; border-radius: 6px; margin-bottom: 8px;">
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <strong style="font-size: 13px;">${p.title}</strong>
        <span class="badge ${idx % 3 === 0 ? 'badge-green' : 'badge-amber'}">${idx % 3 === 0 ? 'SELECTED' : 'NEEDS REVIEW'}</span>
      </div>
      <div style="margin-top: 12px; display: flex; gap: 6px;">
        <button class="btn btn-primary btn-sm" onclick="toast('Marked as Approved for Wedding Album')">✓ Select</button>
        <button class="btn btn-outline btn-sm" onclick="toast('Rejected from selection')">✕ Reject</button>
        <button class="btn btn-outline btn-sm" onclick="promptComment()">💬 Note</button>
      </div>
    </div>
  `).join('');
}

function promptComment() {
  const note = prompt('Enter your client revision note:');
  if (note) toast('Client feedback logged: "' + note + '"');
}

// HEALTH ADVISORY FIXES
function fixDuplicateAdvisory() {
  toast('Applied: Plate 05 replaced with 3/4 length environmental wide shot.');
}
function fixPacingAdvisory() {
  toast('Applied: Pacing adjusted by inserting runway establishing shot.');
}
function dismissAdvisory(el) {
  el.closest('.audit-card').style.display = 'none';
  toast('Advisory dismissed by photographer.');
}

// UPLOAD SIMULATOR
function openUploadModal() {
  const title = prompt('Enter photograph title to ingest:');
  if (!title) return;
  PHOTOS.unshift({
    id: 'p-' + Date.now(),
    title: title,
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCKuYwQ6-sQ5uY59d3rX32j1h4yH74n8vNqfP4B0J8sM6-bK5Q',
    camera: 'Leica M11',
    lens: '50mm Summilux',
    aperture: 'f/1.4',
    shutter: '1/1000s',
    iso: '100',
    dimensions: '9528 × 6328',
    shoot: 'fashion',
    score: 96
  });
  const countBadge = document.getElementById('photo-count-badge');
  if (countBadge) countBadge.innerText = PHOTOS.length;
  toast('Ingested 1 RAW file with EXIF metadata extracted');
  renderLibrary();
}

// DELETE SIMULATOR
function deletePhoto(id) {
  if (currentRole !== 'OWNER') {
    toast('Denied: Only Studio Owner can delete RAW files');
    return;
  }
  const idx = PHOTOS.findIndex(p => p.id === id);
  if (idx !== -1) {
    PHOTOS.splice(idx, 1);
    toast('Photograph removed from master archive');
    closeDrawer();
    renderLibrary();
  }
}

// ROLE SWITCHER
function changeRole(role) {
  currentRole = role;
  toast('Switched role simulation to: ' + role);
  if (role === 'CLIENT') {
    showScreen('proofing');
  }
}

// TOAST
function toast(msg) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.innerText = msg;
  el.style.display = 'block';
  setTimeout(() => {
    el.style.display = 'none';
  }, 3000);
}

// INITIALIZATION
document.addEventListener('DOMContentLoaded', () => {
  renderDashboard();
  renderLibrary();
});
